package com.example;

public class Ordinateur {

    private final String cpu;
    private final int ramGo;
    private final int disqueGo;
    private final boolean gpu;
    private final boolean wifi;

    private Ordinateur(Builder b) {
        this.cpu      = b.cpu;
        this.ramGo    = b.ramGo;
        this.disqueGo = b.disqueGo;
        this.gpu      = b.gpu;
        this.wifi     = b.wifi;
    }

    @Override
    public String toString() {
        return "CPU=" + cpu + ", RAM=" + ramGo + " Go, Disque=" + disqueGo
                + " Go, GPU=" + (gpu  ? "oui" : "non")
                + ", WiFi="  + (wifi ? "oui" : "non");
    }

    // ── classe interne Builder ──────────────────────────────────────────
    public static class Builder {
        private final String cpu;
        private final int    ramGo;
        private int     disqueGo = 256;
        private boolean gpu      = false;
        private boolean wifi     = false;

        public Builder(String cpu, int ramGo) {
            this.cpu   = cpu;
            this.ramGo = ramGo;
        }

        public Builder disque(int go)   { this.disqueGo = go;   return this; }
        public Builder gpu(boolean b)   { this.gpu      = b;    return this; }
        public Builder wifi(boolean b)  { this.wifi     = b;    return this; }

        public Ordinateur build() {
            if (ramGo < 4) {
                throw new IllegalStateException("RAM minimale : 4 Go");
            }
            return new Ordinateur(this);
        }
    }
}

