package com.example;

public class Directeur {
    public static Ordinateur gaming(){
        return new Ordinateur.Builder("i9",32).disque(1000).build();
    }

    public static Ordinateur bureautique() {
        return new Ordinateur.Builder("i3", 8).disque(512).build();
    }
    
}