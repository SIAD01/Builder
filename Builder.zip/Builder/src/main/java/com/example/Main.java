package com.example;

public class Main {
    public static void main(String[] args) {
        Ordinateur gaming = Directeur.gaming();
        Ordinateur bureautique = Directeur.bureautique();
        System.out.println("gaming : "+gaming);
        System.out.println("bureautique = "+bureautique);

        Ordinateur pc1 = new Ordinateur.Builder("i7",16).disque(1000).build();
        System.out.println("pc1 = "+pc1);     

        
    }
}
    